import sys

import pytest

from src.modularize_package import modularize_package


def test_modularize_package():
    # TODO: add test logic
    assert modularize_package


if __name__ == "__main__":
    sys.exit(pytest.main([__file__] + sys.argv[1:]))
